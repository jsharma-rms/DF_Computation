import geopandas as gpd
import pandas as pd
import numpy as np
from shapely.geometry import Polygon
import threading
import time
import DF_Computation as dfcom
import multiprocessing
import glob,os

logFilePath = r'C:\Users\supadhayay\OneDrive - RMS\Repos\DF_Computation\Logs\DF_Computation_1.1_2021_03_12_11_36_26.txt'

def createTempFile(df,filename):
    df = dfcom.checkAndCleanIntersectionsWithin(logFilePath, df, dfcom.getFileName(filename), 99, 0)
    df.to_file(filename)

shp = r'C:\Users\supadhayay\OneDrive - RMS\Data\DF_Computation_Proj\VRG\EQ\EQ_VRG.shp'
outFolder = r'C:\Users\supadhayay\OneDrive - RMS\Data\DF_Computation_Proj\Outputs'
filename = dfcom.getFileName(shp)
if __name__ == '__main__':
    stt = time.time()
    df = gpd.read_file(shp)
    print("time in reading ", time.time() - stt)
    rows = 8
    cols = 8
    [xmin,ymin,xmax,ymax] = df.geometry.total_bounds
    dx = (xmax-xmin)/cols
    dy = (ymax-ymin)/rows
    polys = []
    for i in range(rows):
        for j in range(cols):
            lx = xmin+j*dx
            ux = xmin+(j+1)*dx
            ly = ymin+i*dy
            uy = ymin+(i+1)*dy
            poly = Polygon([(lx,ly),(lx,uy),(ux,uy),(ux,ly),(lx,ly)])
            polys.append(poly)
    dfc = gpd.GeoDataFrame(geometry=polys)
    dfc.crs = df.crs
    dfc['PRT'] = dfc.index
    dfc.to_file(os.path.join(outFolder,filename+"_Divisions.shp"))
    # dfc = gpd.read_file(os.path.join(outFolder,filename+"_Divisions.shp"))
    df['UNQ'] = df.index
    print("Length DF",len(df))
    jdf = gpd.sjoin(df,dfc,how='inner',op='within')
    jdf = jdf.reset_index()
    dfIt = df.loc[~df.UNQ.isin(jdf.UNQ)]
    df = df.loc[df.UNQ.isin(jdf.UNQ)]
    df = df.merge(jdf[['UNQ','PRT']], on='UNQ', how='left')
    print("Length DF",len(df))
    jdf = None
    jdf = gpd.sjoin(dfIt,dfc,how='inner',op='intersects')
    jdf = jdf.reset_index()
    dfIt = dfIt.merge(jdf[['UNQ','PRT']], on='UNQ', how='left')
    crs = df.crs
    df = pd.concat([df, dfIt], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
    df.crs = crs
    df['PRT'] = df['PRT'].astype(int)
    print(list(df['PRT'].unique()))
    print("Length DF",len(df))
    prts = list(df['PRT'].unique())
    threads = []
    tt = time.time()
    lnt = 0
    processes = []
    for prt in prts:
        sdf = df.loc[df.PRT==prt]
        lnt += len(sdf)
        # createTempFile(sdf,brokenPaths.replace('.shp','_'+str(prt)+'.shp'))
        p = multiprocessing.Process(target=createTempFile,args=(sdf,os.path.join(outFolder,filename+'_Broken_'+str(prt)+'.shp'),))
        processes.append(p)
        p.start()
    jdf = None
    df = None
    dfc = None
    for p in processes:
        p.join()
    print("time in cleaning intersection and breaking",time.time()-tt)
    print(lnt)
    tt = time.time()
    files = glob.glob(os.path.join(outFolder, filename+'_Broken_*.shp'))
    print("total broken files",len(files))
    firstLyr = files.pop(0)
    df = gpd.read_file(firstLyr)
    crs = df.crs
    if (len(files) > 0):
        dfremain = pd.concat([
            gpd.read_file(lyr)
            for lyr in files
        ], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
        df = pd.concat([df, dfremain], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
        df.crs = crs
        dfremain = None
    print("time in reading and merging", time.time() - tt)
    tt = time.time()
    df = df.loc[df.Area > 0]
    df['Count'] = df.groupby(['UNQ'])['UNQ'].transform('count')
    dd = df.loc[df.Count > 1]  # all duplicates
    df = df.loc[df.Count < 2]  # only uniques
    if(len(dd)>0):
        ddg = dd.groupby(['UNQ'])
        remainings = {}
        index = 0
        for name, gdf in ddg:
            geom = None
            for i in range(0, len(gdf)):
                if not geom:
                    geom = gdf.iloc[i].to_dict()['geometry']
                else:
                    geom = geom.intersection(gdf.iloc[i].to_dict()['geometry'])
            if(geom and not geom.is_empty and geom.type!='Point'):
                if(not geom.is_valid):
                    geom = geom.buffer(0)
                remainings[index] = gdf.iloc[0].to_dict()
                remainings[index]['geometry'] = geom
                index = index + 1
        remdf = pd.DataFrame.from_dict(remainings, 'index')
        df = pd.concat([df,remdf], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
        df.crs = crs
    print("time in preparing final df", time.time() - tt)
    df.to_file(os.path.join(outFolder,filename+"_B_Clean_1.shp"))
    print("total time", time.time() - stt)

