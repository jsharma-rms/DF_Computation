'''
Author: Suryakant Upadhayay
Purpose: DF Computation Project
'''
import pyodbc
from osgeo import ogr
import sys, os
import time
import tkinter as tk
from tkinter import *
from tkinter import filedialog, messagebox, ttk
from tkinter.ttk import Notebook
import tkinter.font as tkfont
from time import localtime, strftime
import getpass
import tempfile
import re
import glob
import geopandas as gpd
import pandas as pd
import fiona
import math
import numpy as np
from shapely.wkt import loads
from shapely.geometry import Point, LineString,Polygon,shape, mapping
from pyproj import _datadir, datadir
import sqlalchemy
import urllib
import traceback
import threading
from PIL import Image, ImageTk
import multiprocessing

######################### global variables #########################
appVersion = "2.1"
logFolderPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), "Logs")
infoMessageType = "INFORMATION"
warningMessageType = "WARNING"
errorMessageType = "ERROR"
tempDir = tempfile.gettempdir()
appConfigFolder = os.path.join(tempDir,"SDR_App")
appConfigFile = os.path.join(appConfigFolder,"SDR_App_Config.txt")
logoPath = os.path.join(sys._MEIPASS, "lg-logo-rms.png")#os.path.join(os.path.dirname(os.path.realpath(__file__)),"lg-logo-rms.png")##
iconPath = os.path.join(sys._MEIPASS, "df_logo.ico")#os.path.join(os.path.dirname(os.path.realpath(__file__)),"df_logo.ico")##
authChoices = {'SQL Server Authentication', 'Windows Authentication'}
gridRows = 9
gridCols = 10

######################### helper/utility functions #########################
'''get file name from fully qualified path/name'''
def getFileName(filepath):
    filename = os.path.basename(filepath) #This may contain extension. removing that next
    filename = filename.split('.')[0]
    return filename

def getProcessChunks(processes, n):
    for i in range(0, len(processes), n):
        yield processes[i:i + n]

'''checks the geometry type of shapefile'''
def getGeometryTypeOfShapefile(shapeFilePath):
    schema = None
    with fiona.open(shapeFilePath,"r") as source:
        schema = source.schema
    return schema['geometry']

'''This functions gets connection engined after connecting to SQL server database'''
def getSQLConnectionEngine(database, server, username, password, authMode):
    if (authMode == "SQL Server Authentication"):
        params = urllib.parse.quote_plus("Driver = {SQL Server Native Client 11.0};"
                                         "Server=" + server + ";" +
                                         "Database=" +database + ";" +
                                         "username=" + username + ";" +
                                         "password=" + password + ";" +
                                         "Trusted_Connection = yes;")
    else:
        params = urllib.parse.quote_plus("Driver={SQL Server Native Client 11.0};"
                                         "Server=" + server + ";" +
                                         "Database=" + database + ";" +
                                         "Trusted_Connection=yes;")
    engine = sqlalchemy.create_engine('mssql+pyodbc:///?odbc_connect={}'.format(params))
    return engine

'''returns sql server instance generic cursor'''
def getSqlServerInstanceCursor(authMethod,server,username,password,database):
    cn = None
    if(database):
        if (authMethod == "SQL Server Authentication"):
            cn = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                                  "Server=" + server + ";" +
                                  "Database=" + database + ";" +
                                  "username=" + username + ";" +
                                  "password=" + password + ";" +
                                  "Trusted_Connection=yes;")
        else:
            cn = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                                  "Server=" + server + ";" +
                                  "Database=" + database + ";" +
                                  "Trusted_Connection=yes;")
    else:
        if (authMethod == "SQL Server Authentication"):
            cn = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                                "Server=" + server + ";" +
                                "username=" + username + ";" +
                                "password=" + password + ";" +
                                "Trusted_Connection=yes;")
        else:
            cn = pyodbc.connect("Driver={SQL Server Native Client 11.0};"
                                "Server=" + server + ";" +
                                "Trusted_Connection=yes;")

    cn.autocommit = True
    cursor = cn.cursor()
    return [cursor,cn]

'''executes a given query on a cursor'''
def executeQuery(logFilePath, queryStmt, cursor):
        try:
            cursor.execute(queryStmt)
            cursor.commit()
            return True
        except Exception as e:
            logMessage(logFilePath, "An error occurred executing query {}".format(queryStmt))
            logMessage(logFilePath, "Error: {}".format(str(e)))
            cursor.commit()
            return False

'''Reads all the available databases in a sql server instance'''
def getCurrAvailableDbsInServer(authMethod, server, username, password):
    try:
        cursor = getSqlServerInstanceCursor(authMethod, server, username, password, None)[0]
        cursor.execute("select name from sys.databases where database_id not in (1,2,3,4)")
        rows = cursor.fetchall()
        # databaseEntry['menu'].delete(0, 'end')
        dbs = ()
        for row in rows:
            dbs = dbs + (row.name,)
        return dbs
    except Exception as e:
        logMessage(logFilePath, "An error : {0}, occurred getting list of available Dbs in SQL server instance {1}".format(str(e), server))
        showMessageBox("Error", "An error : {0}, occurred getting list of available Dbs in SQL server instance {1}".format(str(e), server),errorMessageType)
        return ()

'''show message boxes of different types'''
def showMessageBox(title, message, type):
    if(type==infoMessageType):
        messagebox.showinfo(title, message)
    elif(type==warningMessageType):
        messagebox.showwarning(title,message)
    else:
        messagebox.showerror(title, message)

'''logs log messages to text log file'''
def logMessage(logFilePath, msg):
        logFolderPath = os.path.join(os.path.dirname(os.path.realpath(__file__)), "Logs")
        if not os.path.exists(logFolderPath):
            os.makedirs(logFolderPath)
        if os.path.exists(logFilePath):
            openMode = 'a'
        else:
            openMode = 'w'
        fh = open(logFilePath, openMode)
        timestamp = '['+strftime("%Y-%m-%d %H:%M:%S", localtime())+']'
        msg = timestamp+ "     "+msg
        if(openMode=='w'):
            fh.write(timestamp + "     "+ "User: {0}".format(getpass.getuser()))
        fh.write("\n")
        fh.write(msg)
        fh.close()
        print(msg)

'''reads configigurations'''
def getConfigs(logFilePath):
    configFilePath = os.path.join(os.path.dirname(os.path.realpath(__file__)), "config.txt")
    config={}
    try:
        for line in open(configFilePath):
            if(len(line.split("=")) == 2):
                config[line.split("=")[0].strip().upper()]=line.split("=")[1].strip()
            elif(len(line.split("=")) > 2):
                line = line.upper()
                cs = line.split("=")
                config[line.split("=")[0].strip().upper()] = "=".join(cs[1:])
            else:
                line = line.upper()  #do nothing
    except Exception as e:
        logMessage(logFilePath,"An error occurred reading application's config file. Error : {}".format(str(e)))
    return config

'''calculates percentage overlap between two geometries'''
def calculateOverlapPercentages(geom1, geom2):
    retPcts = [0,0,0]
    try:
        intgeom = geom1.intersection(geom2)
        geom1Area = geom1.area
        geom2Area = geom2.area
        intgeomArea = intgeom.area
        minPct = min(((intgeomArea / geom1Area) * 100),((intgeomArea / geom2Area) * 100))
        maxPct = max(((intgeomArea / geom1Area) * 100), ((intgeomArea / geom2Area) * 100))
        pct = ((intgeomArea / geom1Area) * 100)
        retPcts = [minPct, maxPct, pct]
    except:
        retPcts = [0, 0, 0] #### do nothing, ignore some special cases of errorred geometries
    return retPcts

'''
Checks for intersections within layer and cleans them.
'''
def checkAndCleanIntersectionsWithin(logFilePath, clnLyrDf, lyrName, intThreshold, areaThreshold, idCol = 'Unique'):
    idColLeft = idCol + '_left'
    idColRight = idCol + '_right'
    tt = time.time()
    delIDCol = False
    colsToDel = ['index_righ', 'index_right', 'level', 'level_0', 'index_left', 'index', 'level_1']
    for col in colsToDel:
        if (col in list(clnLyrDf)):
            del clnLyrDf[col]
    clnLyrDf = clnLyrDf.reset_index()
    if('index' in list(clnLyrDf)):
        del clnLyrDf['index']
    # finding intersection within polygons of a layer
    clnLyrDf.geometry = clnLyrDf.geometry.buffer(0)
    clnLyrDf['Isvalid'] = np.nan
    clnLyrDf['Geom'] = clnLyrDf.geometry
    if(idCol not in list(clnLyrDf)):
        clnLyrDf[idCol] = clnLyrDf.index
        delIDCol = True
    if ('Area' not in list(clnLyrDf)):
        clnLyrDf['Area'] = clnLyrDf.area
    lyrDf = gpd.sjoin(clnLyrDf, clnLyrDf, how='inner', op='intersects')
    lyrDf = lyrDf.reset_index()
    for col in colsToDel:
        if (col in list(clnLyrDf)):
            del clnLyrDf[col]
    lyrDf = lyrDf.loc[lyrDf[idColLeft] != lyrDf[idColRight]]
    logMessage(logFilePath, "Performing geometries intersections in {0} completed in : {1} minutes".format(lyrName, str(
        round((time.time() - tt) / 60, 2))))

    # cleaning/removing intersection
    if (len(lyrDf.index) > 0):  # if overlapping geometries found
        try:
            logMessage(logFilePath, "Total overlapping/Intersecting geometries (duplicate pairs included) {0} : {1}".format(lyrName, str(
                           len(lyrDf.index))))
            lyrDf['UniquePair'] = lyrDf.apply(
                lambda row: math.sqrt(int(row[idColLeft])) + math.sqrt(int(row[idColRight])), axis=1)
            lyrDf = lyrDf.drop_duplicates(['UniquePair']).sort_index()
            logMessage(logFilePath, "Overlapping/Intersecting geometries to be corrected in {0} : {1}".format(lyrName, str(
                len(lyrDf.index))))
            removedIds = []
            remainings = {}
            modifiedGeoms = {}
            index = 0
            for idx, row in lyrDf.iterrows():
                try:
                    cont = True
                    if(row[idColLeft] in removedIds or row[idColRight] in removedIds):
                        cont = False
                    if(cont): ## if this pair is not already taken care
                        [minOvl,maxOvl,ovl] = calculateOverlapPercentages(row['geometry'], row['Geom_right'])
                        if(minOvl > intThreshold and maxOvl > 99.9):   #originally condition was if(minOvl > intThreshold or maxOvl > 99.9). We do not want to remove geometries here if its repairable
                            idtoremove = idColLeft if row['Area_left'] < row['Area_right'] else idColRight
                            if row[idtoremove] not in removedIds:
                                removedIds.append(row[idtoremove])
                        else:
                            lgeom = row['geometry']
                            rgeom = row['Geom_right']
                            ngeom = None
                            if (row[idColLeft] in modifiedGeoms):
                                lgeom = remainings[modifiedGeoms[row[idColLeft]]]['geometry']
                            if (row[idColRight] in modifiedGeoms):
                                rgeom = remainings[modifiedGeoms[row[idColRight]]]['geometry']
                            if(lgeom.area < rgeom.area):
                                ngeom = getIntersectedGeometry(rgeom, lgeom, areaThreshold) #changing right geometry
                                if (row[idColRight] in modifiedGeoms):
                                    remainings[modifiedGeoms[row[idColRight]]]['geometry'] = ngeom
                                else:
                                    dct = {}
                                    dct[idCol] = row[idColRight]
                                    dct['geometry'] = ngeom
                                    remainings[index] = dct
                                    modifiedGeoms[row[idColRight]] = index
                                    index = index + 1
                            else:
                                # changing left geometry
                                ngeom = getIntersectedGeometry(lgeom, rgeom, areaThreshold)
                                if (row[idColLeft] in modifiedGeoms):
                                    remainings[modifiedGeoms[row[idColLeft]]]['geometry'] = ngeom
                                else:
                                    dct = {}
                                    dct[idCol] = row[idColLeft]
                                    dct['geometry'] = ngeom
                                    remainings[index] = dct
                                    modifiedGeoms[row[idColLeft]] = index
                                    index = index + 1
                except Exception as exc:
                    print("************************** "+str(exc)+" **************************")
                    az = 1 #do nothing for now

            #removing the ones which needs to be removed
            clnLyrDf = clnLyrDf.loc[~clnLyrDf[idCol].isin(removedIds)]
            clnLyrDf['geometry'] = clnLyrDf.apply(lambda row: remainings[modifiedGeoms[row[idCol]]]['geometry']
                                    if row[idCol] in modifiedGeoms else row['geometry'], axis = 1)
            clnLyrDf = clnLyrDf.explode()
            clnLyrDf = clnLyrDf.reset_index()
            clnLyrDf['Area'] = clnLyrDf.geometry.area
            clnLyrDf = clnLyrDf.loc[clnLyrDf.Area > areaThreshold]
            clnLyrDf[idCol] = clnLyrDf.index
        except Exception as exc:
            print("**************************# "+str(exc)+" #**************************")
            az = 1 #do nothing for now

    if(delIDCol):
        del clnLyrDf[idCol]
    colsToDel.append('Geom')
    colsToDel.append('Isvalid')
    for col in colsToDel:
        if (col in list(clnLyrDf)):
            del clnLyrDf[col]
    logMessage(logFilePath, "Completed working on intersections checking and cleaning  for {0} in : {1} minutes".format(lyrName, str(
        round((time.time() - tt) / 60, 2))))
    return clnLyrDf

'''gets intersected geometry between two geometries'''
def getIntersectedGeometry(geom1, geom2, areaThreshold):
    ngeom = geom1.difference(geom2).buffer(0)
    return ngeom

'''Purpose: This algorithm intersects a set of polygons with another set of polygons and corrects/clip their geometries
and retains only intersecting polygons. ncdf is input polygons to be clipped, fpDf is input polygons which clips ncdf'''
def correctAndClipSetbacksPerFootprints(logFilePath, fpDf, ncdf, attrsToPopulateInClippedPolys):
    logMessage(logFilePath, "Working on correcting and clipping vrg polygons")
    cols = ['index', 'level_0', 'level_1', 'index_left', 'index_right']
    for attribute in attrsToPopulateInClippedPolys:
        if(attribute in list(ncdf)):
            del ncdf[attribute]
    for col in cols:
        if (col in list(fpDf)):
            del fpDf[col]
        if (col in list(ncdf)):
            del ncdf[col]
    logMessage(logFilePath, 'Validating geometries of both polygon feature classes')
    fpDf.geometry = fpDf.geometry.buffer(0)
    ncdf.geometry = ncdf.geometry.buffer(0)
    # ncdf['Geom'] = ncdf.geometry
    ncdf['UNQ'] = ncdf.index
    logMessage(logFilePath, 'Performing for within spatial join')
    joinDf = gpd.sjoin(ncdf, fpDf, how='inner', op='within')
    logMessage(logFilePath, 'Completed performing within spatial join')
    for col in cols:
        if (col in list(joinDf)):
            del joinDf[col]
    joinDf = joinDf.reset_index()
    logMessage(logFilePath, "within joinDf length: {0}".format(str(len(joinDf))))
    # logMessage(logFilePath, 'checking for geometries to be clipped')
    # joinDf['Clip'] = joinDf.apply(lambda row: (False if row['geometry'].contains(row['Geom']) else True),axis=1)
    # logMessage(logFilePath, 'checking for geometries to be clipped')
    for col in cols:
        if (col in list(joinDf)):
            del joinDf[col]
    logMessage(logFilePath, "populating attributes in polygons whose clipping is not required")

    joinDf = joinDf.drop_duplicates(['UNQ'])

    ncdf = ncdf.merge(joinDf[['UNQ']+attrsToPopulateInClippedPolys], on='UNQ', how='left')

    ncdfOut = ncdf.loc[~ncdf.UNQ.isin(joinDf.UNQ)]
    ncdf = ncdf.loc[ncdf.UNQ.isin(joinDf.UNQ)]
    ncdfOut['Geom'] = ncdfOut.geometry

    logMessage(logFilePath, 'intersects spatial join in progress')
    joinDf = None
    joinDf = gpd.sjoin(fpDf, ncdfOut, how='inner', op='intersects')
    logMessage(logFilePath, 'intersects Spatial join completed')
    for col in cols:
        if (col in list(joinDf)):
            del joinDf[col]
    joinDf = joinDf.reset_index()
    logMessage(logFilePath, "joinDf length: {0}".format(str(len(joinDf))))

    logMessage(logFilePath, "modifying geometries for the polygons which has to be clipped. i.e. clipping polygons")
    modifiedGeoms = {}
    index = 0
    logMessage(logFilePath, "Number of rows to be worked on : {0}".format(str(len(joinDf))))
    for idx, row in joinDf.iterrows():
        dct = ncdf.iloc[0].to_dict()
        keys = list(dct.keys())+attrsToPopulateInClippedPolys
        for key in keys:
            if(key in row):
                dct[key] = row[key]
            elif(key+'_left' in row):
                dct[key] = row[key+'_left']
            elif (key + '_right' in row):
                dct[key] = row[key + '_right']
        ngeom = None
        try:
            ngeom = row.Geom.intersection(row.geometry).buffer(0)
        except:
            try:
                ngeom = row.Geom.intersection(row.geometry.buffer(0.1)).buffer(0)
            except:
                ngeom = row.Geom.buffer(0.1).intersection(row.geometry.buffer(0.1)).buffer(0)
        dct['geometry'] = ngeom
        dct['Area'] = ngeom.area
        dct['UNQ'] = row.UNQ
        modifiedGeoms[index] = dct
        index = index + 1

    logMessage(logFilePath, "focussing on other remainder operations")
    remainSbDf = gpd.GeoDataFrame.from_dict(modifiedGeoms, 'index')
    remainSbDf.crs = ncdf.crs
    remainSbDf.dropna(axis=1, thresh=1)
    joinDf = joinDf.loc[~joinDf.UNQ.isin(remainSbDf.UNQ)]
    ncdfOut = ncdfOut.loc[ncdfOut.UNQ.isin(joinDf.UNQ)]

    ncdf = ncdf.append(remainSbDf, ignore_index=True)
    ncdf = ncdf.reset_index()
    if('index' in list(ncdf)):
        del ncdf['index']
    ncdf.geometry = ncdf.geometry.buffer(0)
    ncdf = ncdf.explode()
    ncdf = ncdf.reset_index()
    if ('index' in list(ncdf)):
        del ncdf['index']
    ncdf['Area'] = ncdf.geometry.area
    ncdf = ncdf.loc[~ncdf.geometry.isna()]
    ncdf = ncdf.loc[ncdf.geometry.is_valid == True]
    cols = ['index', 'level_0', 'level_1', 'Geom', 'index_left', 'index_right', 'UNQ']
    for col in cols:
        if (col in list(ncdf)):
            del ncdf[col]
        if (col in list(fpDf)):
            del fpDf[col]
    joinDf = None
    logMessage(logFilePath, "Completed working on correcting and clipping vrg polygons")
    return ncdf

'''overlays reference points on VRG polygons and populates attributes'''
def overlayAndPopulateAttributesFromRefPoints(logFilePath, fpDf, ncdf, attrsToPopulateInClippedPolys):
    #fpDf  is point geometry here
    logMessage(logFilePath, "Working on overlaying reference points on vrg polygons")
    cols = ['index', 'level_0', 'level_1', 'index_left', 'index_right']
    for attribute in attrsToPopulateInClippedPolys:
        if (attribute in list(ncdf)):
            del ncdf[attribute]
    for col in cols:
        if (col in list(fpDf)):
            del fpDf[col]
        if (col in list(ncdf)):
            del ncdf[col]
    logMessage(logFilePath, 'Validating geometries of vrg polygons')
    ncdf.geometry = ncdf.geometry.buffer(0)
    ncdf['UNQ'] = ncdf.index
    logMessage(logFilePath, 'Performing within spatial join')
    joinDf = gpd.sjoin(fpDf,ncdf, how='inner', op='within')
    logMessage(logFilePath, 'Completed performing within spatial join')
    for col in cols:
        if (col in list(joinDf)):
            del joinDf[col]
    joinDf = joinDf.reset_index()
    logMessage(logFilePath, "within joinDf length: {0}".format(str(len(joinDf))))
    for col in cols:
        if (col in list(joinDf)):
            del joinDf[col]
    joinDf = joinDf.drop_duplicates(['UNQ',attrsToPopulateInClippedPolys[0]])

    #taking care of remaining points which may fall on edges of polygons and not completely inside
    fpDfRem = fpDf.loc[~fpDf[attrsToPopulateInClippedPolys[0]].isin(joinDf[attrsToPopulateInClippedPolys[0]])]#remaining points
    logMessage(logFilePath, 'Performing intersects spatial join')
    joinDf_rem = gpd.sjoin(fpDfRem, ncdf, how='inner', op='intersects')
    logMessage(logFilePath, 'Completed performing intersects spatial join')
    for col in cols:
        if (col in list(joinDf_rem)):
            del joinDf_rem[col]
    joinDf_rem = joinDf_rem.reset_index()
    logMessage(logFilePath, "intersects joinDf_rem length: {0}".format(str(len(joinDf_rem))))
    for col in cols:
        if (col in list(joinDf_rem)):
            del joinDf_rem[col]
    joinDf_rem = joinDf_rem.drop_duplicates([attrsToPopulateInClippedPolys[0]])

    logMessage(logFilePath, "populating attributes of reference points in VRG polygons")
    joinDf = pd.concat([joinDf, joinDf_rem],ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
    ncdf = ncdf.merge(joinDf[['UNQ'] + attrsToPopulateInClippedPolys], on='UNQ', how='left')
    ncdf = ncdf.loc[ncdf.UNQ.isin(joinDf.UNQ)]
    logMessage(logFilePath, "completed populating attributes of reference points in VRG polygons")
    cols = ['index', 'level_0', 'level_1', 'Geom', 'index_left', 'index_right']
    for col in cols:
        if (col in list(ncdf)):
            del ncdf[col]
        if (col in list(fpDf)):
            del fpDf[col]
    joinDf = None
    logMessage(logFilePath, "Completed working on overlaying reference points on vrg polygons")
    return ncdf

'''Populates columns from county/state shapefile to reference shapefile'''
def populateCountyColumnsInReferenceShps(logFilePath,refShapeGeom,referenceShpFile,referenceShpDf,columnsToPopulateinVRG,countyColsToBePopulated,countyShapeFilePath):
    logMessage(logFilePath, "Working on populating columns {0} from county/state {1} to reference file {2} (count={3})"
               .format(str(countyColsToBePopulated),getFileName(countyShapeFilePath),getFileName(referenceShpFile),str(len(referenceShpDf))))
    logMessage(logFilePath,"Reading county/state shapefile {0}".format(getFileName(countyShapeFilePath)))
    cntydf = gpd.read_file(countyShapeFilePath)
    cntydf.geometry = cntydf.geometry.buffer(0)
    cntydf = cntydf.explode()
    cntydf = cntydf.reset_index()
    logMessage(logFilePath, "Completed reading county/state shapefile {0} (Count: {1})".format(getFileName(countyShapeFilePath),str(len(cntydf))))
    referenceShpDf = referenceShpDf.reset_index()
    cols = ['index', 'level_0', 'level_1', 'index_left', 'index_right']
    for col in cols:
        if (col in list(referenceShpDf)):
            del referenceShpDf[col]
        if (col in list(cntydf)):
            del cntydf[col]
    if (referenceShpDf.crs != cntydf.crs):
        logMessage(logFilePath, "Projecting county/state shape file with CRS {0} to the CRS of reference file {1}".format(
            str(cntydf.crs),str(referenceShpDf.crs)))
        cntydf = cntydf.to_crs(referenceShpDf.crs)
        cntydf.crs = referenceShpDf.crs
        logMessage(logFilePath, "Projection completed")
    cntydf = cntydf[countyColsToBePopulated+['geometry']]
    referenceShpDf['UNQ'] = referenceShpDf.index
    if(refShapeGeom=='POINT'):
        logMessage(logFilePath, 'Performing within spatial join')
        joinDf = gpd.sjoin(referenceShpDf, cntydf, how='inner', op='within')
        logMessage(logFilePath, 'Completed performing within spatial join')
        for col in cols:
            if (col in list(joinDf)):
                del joinDf[col]
        joinDf = joinDf.reset_index()
        logMessage(logFilePath, "populating attributes in reference points")
        joinDf = joinDf.drop_duplicates(['UNQ'])
        referenceShpDf = referenceShpDf.merge(joinDf[['UNQ'] + countyColsToBePopulated], on='UNQ', how='left')
        logMessage(logFilePath, "completed populating attributes in reference points")
    else:
        cntydf['Geom'] = cntydf.geometry
        logMessage(logFilePath, 'performing intersects Spatial join')
        joinDf = gpd.sjoin(referenceShpDf, cntydf, how='inner', op='intersects')
        logMessage(logFilePath, 'intersects Spatial join completed')
        for col in cols:
            if (col in list(joinDf)):
                del joinDf[col]
        joinDf = joinDf.reset_index()
        logMessage(logFilePath, "joinDf length: {0}".format(str(len(joinDf))))
        if(len(joinDf)>0):
            joinDf['FP_Overlap'] = joinDf.apply(lambda row: calculateOverlapPercentages(row['geometry'], row['Geom'])[2], axis=1)
            joinDf = joinDf.sort_values('FP_Overlap', ascending=False).drop_duplicates('UNQ').sort_index()
            logMessage(logFilePath, "populating attributes in reference polygons")
            joinDf = joinDf.drop_duplicates(['UNQ'])
            referenceShpDf = referenceShpDf.merge(joinDf[['UNQ'] + countyColsToBePopulated], on='UNQ', how='left')
            logMessage(logFilePath, "completed populating attributes in reference polygons")

    if('UNQ' in list(referenceShpDf)):
        del referenceShpDf['UNQ']
    logMessage(logFilePath, "Completed working on populating columns {0} from county/state {1} to reference file {2} (Count={3})"
               .format(str(countyColsToBePopulated), getFileName(countyShapeFilePath), getFileName(referenceShpFile),str(len(referenceShpDf))))
    return referenceShpDf

def createGridDivisions(logFilePath,rows,cols,outFolder,filename,df,crateDivisionShapefile):
    logMessage(logFilePath,"Working on creating grid shapes")
    [xmin, ymin, xmax, ymax] = df.geometry.total_bounds
    dx = (xmax - xmin) / cols
    dy = (ymax - ymin) / rows
    polys = []
    for i in range(rows):
        for j in range(cols):
            lx = xmin + j * dx
            ux = xmin + (j + 1) * dx
            ly = ymin + i * dy
            uy = ymin + (i + 1) * dy
            poly = Polygon([(lx, ly), (lx, uy), (ux, uy), (ux, ly), (lx, ly)])
            polys.append(poly)
    dfc = gpd.GeoDataFrame(geometry=polys)
    dfc.crs = df.crs
    dfc['PRT'] = dfc.index
    if(crateDivisionShapefile):
        dfc.to_file(os.path.join(outFolder, filename + "_Divisions.shp"))
    logMessage(logFilePath, "Completed working on creating grid shapes")
    return dfc

def cleanAndCreateTempFile(logFilePath,df,filename):
    df = checkAndCleanIntersectionsWithin(logFilePath, df, getFileName(filename), 99, 0)
    # logMessage(logFilePath, "Creating temporary broken file: {0}".format(getFileName(filename)))
    df.to_file(filename)
    # logMessage(logFilePath, "Completed creating temporary broken file: {0}".format(getFileName(filename)))

def breakCheckAndCleanIntersectionsForLargeFiles(logFilePath,outFolder,filename,df):
    ttt = time.time()
    crateDivisionShapefile  = True
    dfc = createGridDivisions(logFilePath,gridRows,gridCols,outFolder,filename,df,crateDivisionShapefile)
    df['UNQ'] = df.index
    logMessage(logFilePath, "Total features to break in {0}: {1}".format(filename,str(len(df))))
    logMessage(logFilePath,"Performing spatial join (within) between grids and {0}".format(filename))
    jdf = gpd.sjoin(df, dfc, how='inner', op='within')
    jdf = jdf.reset_index()
    logMessage(logFilePath, "Completed performing spatial join (within) between grids and {0}".format(filename))
    dfIt = df.loc[~df.UNQ.isin(jdf.UNQ)]
    df = df.loc[df.UNQ.isin(jdf.UNQ)]
    df = df.merge(jdf[['UNQ', 'PRT']], on='UNQ', how='left')
    logMessage(logFilePath,"Performing spatial join (intersection) between grids and {0} ({1})".format(filename,str(len(dfIt))))
    jdf = None
    jdf = gpd.sjoin(dfIt, dfc, how='inner', op='intersects')
    jdf = jdf.reset_index()
    logMessage(logFilePath, "Completed performing spatial join (intersection) between grids and {0}".format(filename))
    dfIt = dfIt.merge(jdf[['UNQ', 'PRT']], on='UNQ', how='left')
    crs = df.crs
    df = pd.concat([df, dfIt], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
    df.crs = crs
    df['PRT'] = df['PRT'].astype(int)
    prts = list(df['PRT'].unique())
    logMessage(logFilePath,"Features({0} including duplicates) in {1} will be broken in {2} parts".format(str(len(df)),filename,str(len(prts))))
    tt = time.time()
    lnt = 0
    processes = []
    numProcesses = 15
    configs = getConfigs(logFilePath)
    if(configs and 'MAX_PROCESSES' in configs):
        try:
            numProcesses = int(configs['MAX_PROCESSES'])
        except Exception as ex:
            logMessage(logFilePath,"An error occurred reading MAX_PROCESSES from config file. Error: {0}".format(str(ex)))
    logMessage(logFilePath,"Working on creating partitions as processes")
    for prt in prts:
        sdf = df.loc[df.PRT == prt]
        lnt += len(sdf)
        # createTempFile(sdf,brokenPaths.replace('.shp','_'+str(prt)+'.shp'))
        p = multiprocessing.Process(target=cleanAndCreateTempFile,
                                    args=(logFilePath,sdf, os.path.join(outFolder, filename + '_Broken_' + str(prt) + '.shp'),))
        processes.append(p)
    jdf = None
    df = None
    dfc = None
    logMessage(logFilePath, "Completed working on creating partitions as processes")
    logMessage(logFilePath,"Working on cleaning intersections and creating temporary broken shape files")
    for i in getProcessChunks(processes, numProcesses):
        for j in i:
            j.start()
        for j in i:
            j.join()
    logMessage(logFilePath, "Completed working on cleaning intersections and creating temporary broken shape files in:"
                            " {0} minutes".format(str((time.time() - tt)/60)))
    print(lnt)
    tt = time.time()
    files = glob.glob(os.path.join(outFolder, filename + '_Broken_*.shp'))
    logMessage(logFilePath,"Reading and combining clean broken files: {0}".format(str(len(files))))
    firstLyr = files.pop(0)
    df = gpd.read_file(firstLyr)
    crs = df.crs
    if (len(files) > 0):
        dfremain = pd.concat([
            gpd.read_file(lyr)
            for lyr in files
        ], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
        df = pd.concat([df, dfremain], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
        df.crs = crs
        dfremain = None
    logMessage(logFilePath,"Completed reading and combining clean broken files (Total features: {0})".format(str(len(df))))
    tt = time.time()
    logMessage(logFilePath, "Working on combining duplicate features to correct their shapes")
    df = df.loc[df.Area > 0]
    df['Count'] = df.groupby(['UNQ'])['UNQ'].transform('count')
    dd = df.loc[df.Count > 1]  # all duplicates
    df = df.loc[df.Count < 2]  # only uniques
    if (len(dd) > 0):
        ddg = dd.groupby(['UNQ'])
        remainings = {}
        index = 0
        for name, gdf in ddg:
            geom = None
            for i in range(0, len(gdf)):
                if not geom:
                    geom = gdf.iloc[i].to_dict()['geometry']
                else:
                    geom = geom.intersection(gdf.iloc[i].to_dict()['geometry'])
            if (geom and not geom.is_empty and geom.type != 'Point'):
                if (not geom.is_valid):
                    geom = geom.buffer(0)
                remainings[index] = gdf.iloc[0].to_dict()
                remainings[index]['geometry'] = geom
                index = index + 1
        remdf = pd.DataFrame.from_dict(remainings, 'index')
        df = pd.concat([df, remdf], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
        df.crs = crs
    logMessage(logFilePath, "Completed working on combining duplicate features to correct their shapes")
    for fl in glob.glob(os.path.join(outFolder, filename + '_Broken_*')):
        os.remove(fl)
    colsToRemove = ['PRT','UNQ','Count','index','level_0','level_1','index_left','index_right']
    for col in colsToRemove:
        if(col in list(df)):
            del df[col]
    logMessage(logFilePath,"Completed cleaning intersections (by breaking and combining) finally in {0} (Total Features: {1}) in : {2} minutes"
               .format(filename,str(len(df)),str((time.time() - ttt)/60)))
    return df


######################### Main / Starting functions for DF computation #########################

'''Starts DF computation algorithms'''
def startDFComputation(outputFolder, logFilePath, vrgFiles, referenceShpFile, countyShapeFilePath, outputShapefileName, outputTableName,
                       columnsToPopulateinVRG, countyColsToBePopulated, projEpsgCode, username, password, authMode, server, database,progressBar,
                       statusLabel,uiElements,usernameEntry,passwordEntry):
    success = True
    try:
        stt = time.time()
        stepsCount = 8
        progStep = 1
        progressBar.pack(anchor="sw", side="bottom", padx=14, pady=14)
        progressBar["maximum"] = 100
        progressBar["value"] = 5
        logMessage(logFilePath, 'DF Computation process started')
        projCRSEspg = None
        vrgFileName = getFileName(vrgFiles[0])
        if(projEpsgCode.startswith("10")):
            projCRSEspg = {"init": "ESRI:{0}".format(projEpsgCode)}
        else:
            projCRSEspg = {"init": "EPSG:{0}".format(projEpsgCode)}
        logMessage(logFilePath, "Projected CRS used for Area Calculation: {0}".format(projCRSEspg))
        colsToDelete = ['OBJECTID', 'SHAPE_AREA', 'SHAPE_LENGTH','SHAPE_LENG', 'INDEX', 'INDEX_LEFT','INDEX_RIGHT','LEVEL','LEVEL_0','LEVEL_1','AREA', 'REF_ID']
        setStatusonUI(statusLabel,
                      "Step ({0}) of ({1}): Reading VRG Shapefiles".format(str(progStep), str(stepsCount)))
        progStep = progStep+1
        logMessage(logFilePath, "Reading VRG files: {0}".format(str(vrgFiles)))
        firstVrgLyr = vrgFiles.pop(0)
        vrgDf = gpd.read_file(firstVrgLyr)
        origCRS = vrgDf.crs
        if (len(vrgFiles) > 0):
            dfremain = pd.concat([
                gpd.read_file(lyr)
                for lyr in vrgFiles
            ], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
            vrgDf = pd.concat([vrgDf, dfremain], ignore_index=True, sort=False).pipe(gpd.GeoDataFrame)
            vrgDf.crs = origCRS
            dfremain = None

        logMessage(logFilePath,"Completed reading VRG files, Features Count: {0}, CRS: {1}".format(
                            str(len(vrgDf)), str(origCRS)))
        progressBar["value"] = progressBar["value"] + 5
        setStatusonUI(statusLabel,
                      "Step ({0}) of ({1}): Cleaning VRG Shapes".format(str(progStep), str(stepsCount)))
        progStep = progStep + 1
        configs = getConfigs(logFilePath)
        if((configs and 'BREAK_TO_CLEAN' in configs and configs['BREAK_TO_CLEAN'].upper()!='YES') or (len(vrgDf)<200000)):
            vrgDf = checkAndCleanIntersectionsWithin(logFilePath, vrgDf, vrgFileName, 99, 0)
        else:
            vrgDf = breakCheckAndCleanIntersectionsForLargeFiles(logFilePath,outputFolder,vrgFileName,vrgDf)
        logMessage(logFilePath, "Calculating centroid of VRG polygons")
        vrgDf['X'] = vrgDf.representative_point().x
        vrgDf['Y'] = vrgDf.representative_point().y
        logMessage(logFilePath, "Completed calculating centroid of VRG polygons")
        # vrgDf.to_file(os.path.join(outputFolder, vrgFileName.replace(".shp", "_Clean.shp")))

        # vrgDf = gpd.read_file(os.path.join(outputFolder,vrgFileName.replace(".shp","_Clean.shp")))
        # origCRS = vrgDf.crs

        progressBar["value"] = progressBar["value"] + 30
        setStatusonUI(statusLabel,
                      "Step ({0}) of ({1}): Reading Refernce Shapefile: {2}".format(str(progStep), str(stepsCount),
                                                                                getFileName(referenceShpFile)))
        progStep = progStep + 1
        refShapeGeom = getGeometryTypeOfShapefile(referenceShpFile).upper()
        logMessage(logFilePath, "Reading Reference Shape file : {0}".format(getFileName(referenceShpFile)))
        referenceShpDf = gpd.read_file(referenceShpFile)
        refShpOriginCRS = referenceShpDf.crs
        referenceShpDf['ZIP_TYPE'] = refShapeGeom
        referenceShpDf['REF_ID'] = referenceShpDf.index
        if(refShapeGeom != 'POINT'):
            referenceShpDf = referenceShpDf.to_crs(projCRSEspg)
            referenceShpDf.crs = projCRSEspg
            referenceShpDf[columnsToPopulateinVRG[1]] = referenceShpDf.area
            referenceShpDf = referenceShpDf.to_crs(refShpOriginCRS)
            referenceShpDf.crs = refShpOriginCRS
            referenceShpDf = referenceShpDf.explode()
        referenceShpDf = referenceShpDf.reset_index()
        logMessage(logFilePath,"Completed reading reference shape file : {0}, Features Count: {1}, CRS: {2}".format(getFileName(referenceShpFile),
                              str(len(referenceShpDf)),str(referenceShpDf.crs)))
        if(len(countyColsToBePopulated)>0):
            setStatusonUI(statusLabel,"Step ({0}) of ({1}): Populating columns from {2} to {3}".format(str(progStep),
                              str(stepsCount),getFileName(countyShapeFilePath),getFileName(referenceShpFile)))
            referenceShpDf = populateCountyColumnsInReferenceShps(logFilePath,refShapeGeom,referenceShpFile,referenceShpDf,
                                                                  columnsToPopulateinVRG,countyColsToBePopulated,countyShapeFilePath)
        if (referenceShpDf.crs != vrgDf.crs):
            logMessage(logFilePath,"Projecting reference shape file with CRS {0} to the CRS of vrg file {1}".format(str(referenceShpDf.crs),
                           str(vrgDf.crs)))
            referenceShpDf = referenceShpDf.to_crs(vrgDf.crs)
            referenceShpDf.crs = vrgDf.crs
            logMessage(logFilePath, "Projection completed")
        if('REF_ID' not in columnsToPopulateinVRG):
            columnsToPopulateinVRG.append('REF_ID')
        if ('ZIP_TYPE' not in columnsToPopulateinVRG):
            columnsToPopulateinVRG.append('ZIP_TYPE')

        progressBar["value"] = progressBar["value"] + 5
        if(refShapeGeom != 'POINT'):
            setStatusonUI(statusLabel,
                          "Step ({0}) of ({1}): Clipping VRG Shapefiles using {2}".format(str(progStep), str(stepsCount),
                                                                                        getFileName(referenceShpFile)))
            progStep = progStep + 1
            vrgDf = correctAndClipSetbacksPerFootprints(logFilePath, referenceShpDf, vrgDf, columnsToPopulateinVRG)
        else:
            setStatusonUI(statusLabel,"Step ({0}) of ({1}): Overlaying reference points ({2}) on VRG polygons".format(str(progStep),
                         str(stepsCount),getFileName(referenceShpFile)))
            progStep = progStep + 1
            vrgDf = overlayAndPopulateAttributesFromRefPoints(logFilePath, referenceShpDf, vrgDf, columnsToPopulateinVRG)

        progressBar["value"] = progressBar["value"] + 30
        setStatusonUI(statusLabel,
                      "Step ({0}) of ({1}): Calculating VRG polygons Area".format(str(progStep), str(stepsCount)))
        progStep = progStep + 1
        logMessage(logFilePath, "Calculating VRG area")
        vrgDf = vrgDf.reset_index()
        vrgDf['VRGID'] = vrgDf.index
        vrgDf = vrgDf.to_crs(projCRSEspg)
        vrgDf.crs = projCRSEspg
        vrgDf['VRG_Area'] = vrgDf.area
        vrgDf = vrgDf.to_crs(origCRS)
        vrgDf.crs = origCRS
        #geoid column
        geoidCol = None
        for col in list(vrgDf):
            if (col.upper().strip() == 'GEOID'):
                geoidCol = col
                break

        logMessage(logFilePath, "Completed calculating VRG area")
        progressBar["value"] = progressBar["value"] + 5
        setStatusonUI(statusLabel,
                      "Step ({0}) of ({1}): Calculating DF".format(str(progStep), str(stepsCount)))
        progStep = progStep + 1
        logMessage(logFilePath, "Calculating DF & TDF")
        if(refShapeGeom != 'POINT'):
            vrgDf[columnsToPopulateinVRG[1]] = vrgDf.groupby('REF_ID')['VRG_Area'].transform('sum')
            vrgDf['DF'] = vrgDf['VRG_Area'] / vrgDf[columnsToPopulateinVRG[1]]
            vrgDf['TDF'] = vrgDf.groupby('REF_ID')['DF'].transform('sum')
        else:
            vrgDf['DF'] = 1
            vrgDf['TDF'] = vrgDf.groupby(['REF_ID','VRGID'])['DF'].transform('sum')

        vrgDf.TDF = vrgDf.TDF.round(2)
        logMessage(logFilePath, "Completed calculating DF & TDF")
        #getting all postcodes/counties which do overlap with any VRG
        referenceShpDf = referenceShpDf.loc[~referenceShpDf[columnsToPopulateinVRG[0]].isin(vrgDf[columnsToPopulateinVRG[0]])]
        for col in list(vrgDf):
            if(col.upper() in colsToDelete):
                del vrgDf[col]
        progressBar["value"] = progressBar["value"] + 5
        setStatusonUI(statusLabel,
                      "Step ({0}) of ({1}): Creating output shape file {2}".format(str(progStep), str(stepsCount),outputShapefileName))
        progStep = progStep + 1
        vrgDf[geoidCol] = vrgDf[geoidCol].astype(str)
        vrgDf[geoidCol] = vrgDf.apply(lambda row: str(row[geoidCol]).split(".")[0], axis=1)
        logMessage(logFilePath, "Creating final output shapefile: {0}".format(outputShapefileName))
        if('UNQ' in list(vrgDf)):
            vrgDfCp = vrgDf.copy()
            vrgDfCp = vrgDfCp.drop_duplicates(['UNQ'])
            del vrgDfCp['UNQ']
            del vrgDf['UNQ']
            vrgDfCp.to_file(os.path.join(outputFolder, outputShapefileName))
        else:
            vrgDf.to_file(os.path.join(outputFolder, outputShapefileName))
        logMessage(logFilePath, "Completed creating final output shapefile: {0}".format(outputShapefileName))
        engine = getSQLConnectionEngine(database, server, username, password, authMode)
        del vrgDf['geometry']
        progressBar["value"] = progressBar["value"] + 5
        setStatusonUI(statusLabel,
                      "Step ({0}) of ({1}): Creating output table {2} in database {3}".format(str(progStep), str(stepsCount),
                                                                                   outputTableName,database))
        progStep = progStep + 1
        logMessage(logFilePath, "Creating final output table: {0} in Database: {1}".format(outputTableName, database))
        if ('REF_ID' in columnsToPopulateinVRG):
            columnsToPopulateinVRG.remove('REF_ID')
        referenceShpDf['DF'] = 1
        referenceShpDf['TDF'] = 1
        columnsToPopulateinVRG.append('DF')
        columnsToPopulateinVRG.append('TDF')
        if (refShapeGeom == 'POINT'):
            vrgDf = pd.concat([vrgDf, referenceShpDf[columnsToPopulateinVRG]], ignore_index=True, sort=False)
            vrgDf[geoidCol] = vrgDf.apply(lambda row: str(row[geoidCol]) if str(row[geoidCol])!='nan' else 'TEST', axis=1)
        else:
            vrgDf['DF'] = vrgDf.groupby([geoidCol,columnsToPopulateinVRG[0]])['DF'].transform('sum')
            vrgDf = vrgDf.sort_values('VRG_Area', ascending=False).drop_duplicates([geoidCol,columnsToPopulateinVRG[0]])

        vrgDf.to_sql(name=outputTableName, if_exists='replace', schema='dbo',
                       index=False, con=engine, dtype={col: sqlalchemy.types.VARCHAR(length=256)
                              for col in vrgDf.columns if((vrgDf[col].dtype == object))})
        logMessage(logFilePath, "Completed creating final output table: {0} in Database: {1}".format(outputTableName, database))
        ########## Completed DF Computation ##############
        timeInMins = round((time.time() - stt) / 60, 2)
        timeElapsedStr = "{0} {1}".format(str(timeInMins), "minutes")
        if (round((time.time() - stt) / 60, 2) > 60):
            timeElapsedStr = "{0} {1}".format(str(round(timeInMins / 60, 2)), "hours")
        logMessage(logFilePath, 'DF Computation process completed in : {0}'.format(timeElapsedStr))
        success = True
    except Exception as e:
        logMessage(logFilePath, "An error occurred in DF computation process.")
        traceback.print_exc()
        err = traceback.format_exc()
        logMessage(logFilePath, "Following: Error Traceback for development")
        logMessage(logFilePath, str(err))
        success = False

    finsihExecutingDFComputation(success, authMode, statusLabel, progressBar, uiElements, usernameEntry, passwordEntry)

############################################ UI and related functions ############################################################
'''Adds a server name entry in to favourite server configuration file'''
def createEntryForFavouriteServerInstance(server):
    if not os.path.exists(appConfigFolder):
        os.makedirs(appConfigFolder)
    if os.path.exists(appConfigFile):
        openMode = 'a'
    else:
        openMode = 'w'
    fh = open(appConfigFile, openMode)
    if(openMode=='w'):
        fh.write(server)
    else:
        favServers = getFavouriteServersTuple()
        if(server not in favServers):
            fh.write(","+server)
    fh.close()

'''browse button action handler for selecting directory'''
def browseDirectoryFunc(browsebutton):
    filename = filedialog.askdirectory()
    if (filename):
        browsebutton.config(text=filename, anchor="w")

'''browse button action handler for selecting files'''
def browseFilesFunc(browsebutton, ftypes):
    filename = filedialog.askopenfilename(filetypes=ftypes)
    if(filename):
        browsebutton.config(text=filename, anchor="w")

'''authentication mode change action handler'''
def conn_method_changed(tkVar, usernameEntry, passwordEntry):
    if (tkVar.get() == "SQL Server Authentication"):
        usernameEntry.config(state='normal')
        passwordEntry.config(state='normal')
    else:
        usernameEntry.config(state='disabled')
        passwordEntry.config(state='disabled')

'''Sets the status text on UI'''
def setStatusonUI(statusLabel, status):
    statusLabel.config(text=status)

'''run button action handler for address processing'''
def executeDFComputation(countyShapeFilePath, vrgFilePath, refShpFilePath,outFolder,database,server,username,password,authMode,outputShapeFileName,
                         outputTableName,columnsToPopulate,projEpsgCode,progressBar,statusLabel,uiElements,usernameEntry,passwordEntry):
    countyGeomType = None
    if(countyShapeFilePath and countyShapeFilePath != 'Browse'):
        countyGeomType = getGeometryTypeOfShapefile(countyShapeFilePath).upper()
        if (not (countyGeomType == 'POLYGON' or countyGeomType == 'MULTIPOLYGON')):
            showMessageBox("Warning", "County/State Shapefile must have polygons geometry", warningMessageType)
            return
    if (not vrgFilePath or vrgFilePath == 'Browse' or len(glob.glob(os.path.join(vrgFilePath,'*.shp')))==0):
        showMessageBox("Warning", "Please select a valid VRG shapes folder",warningMessageType)
        return
    vrgFiles = []
    files = glob.glob(os.path.join(vrgFilePath,'*.shp'))
    for file in files:
        if(getGeometryTypeOfShapefile(file).upper()=='POLYGON'):
            vrgFiles.append(file)
    if (len(vrgFiles) == 0):
        showMessageBox("Warning", "Please select a valid VRG shapes folder", warningMessageType)
        return
    if (not refShpFilePath or refShpFilePath == 'Browse'):
        showMessageBox("Warning", "Please select Reference Shapefile", warningMessageType)
        return
    refGeomType = getGeometryTypeOfShapefile(refShpFilePath).upper()
    if (not (refGeomType == 'POLYGON' or refGeomType == 'MULTIPOLYGON' or refGeomType == 'POINT')):
        showMessageBox("Warning", "Reference Shapefile must have polygons geometry", warningMessageType)
        return
    if (not outFolder or outFolder == 'Browse'):
        showMessageBox("Warning", "Please select output folder",warningMessageType)
        return
    if (not server):
        showMessageBox("Warning", "Please enter a valid SQL server instance", warningMessageType)
        return
    if (not database or database == 'None'):
        showMessageBox("Warning", "Please select a database", warningMessageType)
        return
    if (authMode == "SQL Server Authentication" and (not usernameEntry.get() or not passwordEntry.get())):
        showMessageBox("Warning", "Please enter credentials", warningMessageType)
        return
    if(not columnsToPopulate):
        showMessageBox("Warning", "Please select columns from reference shapefile to populate in VRG", warningMessageType)
        return
    if (not projEpsgCode or len(projEpsgCode) < 4 or len(projEpsgCode) > 8 or not projEpsgCode.isnumeric()):
        showMessageBox("Warning", "Please enter a valid projected crs's epsg code",
                       warningMessageType)
        return
    columnsToPopulateinVRG = [el.strip() for el in columnsToPopulate.split(',')]
    if(refGeomType != 'POINT' and len(columnsToPopulateinVRG)<2):
        showMessageBox("Warning", "At least 2 columns names are required",warningMessageType)
        return
    refShpProps = None
    with fiona.open(refShpFilePath, "r") as source:
        refShpProps = source.schema['properties']
    notAvailableCols = []
    countyColsToBePopulated = []
    for i in range(len(columnsToPopulateinVRG)):
        if (refGeomType == 'POINT' or i != 1):  # second column is area column, for polygon geometries, which will be calculated/created later. Hence skipping that
            if (columnsToPopulateinVRG[i] not in refShpProps):
                notAvailableCols.append(columnsToPopulateinVRG[i])
    if (len(notAvailableCols)>0):
        #check for these columns availability in county/state shapefile
        notAvailableColsFinal = []
        if(countyGeomType):
            countyShpProps = None
            with fiona.open(countyShapeFilePath, "r") as source:
                countyShpProps = source.schema['properties']
            for i in range(len(notAvailableCols)):
                if (notAvailableCols[i] not in countyShpProps):
                    notAvailableColsFinal.append(notAvailableCols[i])
                else:
                    countyColsToBePopulated.append(notAvailableCols[i])
        else:
            notAvailableColsFinal = notAvailableCols
        if(len(notAvailableColsFinal) > 0):
            logMessage(logFilePath,
                       "Columns ({0}) not found in reference or county/states shapefile".format(str(notAvailableColsFinal)))
            showMessageBox("Error",
                           "Columns ({0}) not found in reference or county/states shapefile".format(str(notAvailableColsFinal)),
                           errorMessageType)
            return
    dbs = getCurrAvailableDbsInServer(authMode, server, username, password)
    if (database not in dbs):
        result = messagebox.askyesno("New Database",
                                     "Database {} does not exist.\n Do you want to create new database?".format(
                                         database), icon='warning')
        if result == True:
            cursor = getSqlServerInstanceCursor(authMode, server, username, password, None)[0]
            createDbQStmt = "CREATE DATABASE " + database + ";"
            success = executeQuery(logFilePath, createDbQStmt, cursor)
            dbLogSimpleQueryStmt = "ALTER DATABASE " + database + " SET RECOVERY SIMPLE;"
            success = executeQuery(logFilePath, dbLogSimpleQueryStmt, cursor)
            if not success:
                showMessageBox("Error", "Error creating a new database {}".format(database), errorMessageType)
                return
            else:
                logMessage(logFilePath,
                           "Database {0} created successfully in SQL server instance {1}".format(database, server))
        else:
            return

    if (not outputShapeFileName):
        outputShapeFileName = os.path.basename(vrgFiles[0]).replace(".shp", "_Final.shp")
    if(not outputShapeFileName.endswith(".shp")):
        outputShapeFileName = outputShapeFileName + ".shp"
    if(not outputTableName):
        outputTableName = getFileName(vrgFiles[0])
    if (outputTableName.endswith(".shp")):
        outputTableName = outputTableName.replace(".shp","")
    outputShapeFileName = outputShapeFileName.strip()
    outputTableName = outputTableName.strip()

    if(os.path.exists(os.path.join(outFolder,outputShapeFileName))):
        result = messagebox.askyesno("Overwrite","Output shapefile '{0}' already exist and will be overwritten."
                              " Do you want to continue?".format(outputShapeFileName), icon='warning')
        if result == False:
            return
    cursor = getSqlServerInstanceCursor(authMode, server, username, password, database)[0]
    if cursor.tables(table=outputTableName, tableType='TABLE').fetchone():
        result = messagebox.askyesno("Overwrite", "Output Table '{0}' already exist and will be overwritten."
                       " Do you want to continue?".format(outputTableName),icon='warning')
        if result == False:
            return

    for elm in uiElements:
        elm['state'] = 'disabled'
    usernameEntry['state']='disabled'
    passwordEntry['state'] = 'disabled'
    threading.Thread(target=startDFComputation,  args=(outFolder, logFilePath, vrgFiles, refShpFilePath, countyShapeFilePath, outputShapeFileName, outputTableName,
                           columnsToPopulateinVRG, countyColsToBePopulated, projEpsgCode, username, password, authMode, server, database,progressBar,statusLabel,uiElements,usernameEntry,passwordEntry,)).start()

'''This class is used to create tooltip functionality in the widget elements'''
class CreateToolTip(object):
    '''
    create a tooltip for a given widget
    '''
    def __init__(self, widget, text='widget info'):
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.close)
    def enter(self, event=None):
        x = y = 0
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        # creates a toplevel window
        self.tw = tk.Toplevel(self.widget)
        # Leaves only the label and removes the app window
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        label = tk.Label(self.tw, text=self.text, justify='left',
                       background='whitesmoke', relief='solid', borderwidth=1,
                       font=("times", "8", "normal"))
        label.pack(ipadx=1)
    def close(self, event=None):
        if self.tw:
            self.tw.destroy()

'''creates a connection to sql server to get list of available databases'''
def connectToSQLServer(server, username, password, databaseEntrys, authMethod, dbVar, nb,serverEntry):
    try:
        logMessage(logFilePath, "Server:" + server)
        if (server):
            dbs = getCurrAvailableDbsInServer(authMethod, server, username, password)
            for databaseEntry in databaseEntrys:
                databaseEntry['values']= dbs
            createEntryForFavouriteServerInstance(server)
            if(len(dbs)>0):
                showMessageBox("Success", "Connection successful",infoMessageType)
                serverEntry['values'] = getFavouriteServersTuple()
        else:
            showMessageBox("Warning", "Please enter a valid SQL server instance", warningMessageType)
    except Exception as e:
        showMessageBox("Failed", "Failed to connect to database. Error: {}".format(str(e)), errorMessageType)

'''show message boxes of different types'''
def showMessageBox(title, message, type):
    if(type==infoMessageType):
        messagebox.showinfo(title, message)
    elif(type==warningMessageType):
        messagebox.showwarning(title,message)
    else:
        messagebox.showerror(title, message)

'''windows closing event handler'''
def on_closing():
    global cancelled
    if messagebox.askokcancel("Quit", "Do you want to quit?"):
        cancelled = True
        #time.sleep(1)
        os._exit(1)


'''reads app config file for favourite servers'''
def getFavouriteServersFileContents():
    f = open(appConfigFile,'r')
    return f.read()

'''Reads app favourite server configuration file and returns favourite/last-used server names'''
def getFavouriteServersTuple():
    favServers = ()
    if os.path.exists(appConfigFile):
        try:
            favServersFileContents = getFavouriteServersFileContents()
            favServersArr = favServersFileContents.split(',')
            for favServer in favServersArr:
                favServer = favServer.strip()
                if(favServer not in favServers):
                    favServers = favServers + (favServer, )
        except Exception as e:
            logMessage(logFilePath, "An error occurred getting favourite servers list. Error : {}".format(str(e)))
    else:
        logMessage(logFilePath, "No favourite servers found")
    return favServers

'''finish executing main thread process and stops a progress bar'''
def finsihExecutingDFComputation(success,authMode,statusLabel, progressbar,uiElements,usernameEntry,passwordEntry):
    progressbar.stop()
    progressbar.pack_forget()
    statusLabel.config(text="")
    for elm in uiElements:
        elm['state'] = 'normal'
    if (authMode == "SQL Server Authentication"):
        usernameEntry['state'] = 'normal'
        passwordEntry['state'] = 'normal'

    if success:
        showMessageBox("Success", "Process Complete", infoMessageType)
    else:
        showMessageBox("Error", "Error occurred.\nPlease check log for more details.", errorMessageType)

    #a thread in python does not have a exit() method and thus will thrown an exception.
    # We are not doing anything on exception.
    # Purpose here is to get the exception purposefully to stop this thread from running
    threading.current_thread().exit()



'''UI creator function'''
def createUI(appStartTimestamp):
    root = Tk()
    root.title("DF_Computation_"+appVersion+" [" + getpass.getuser() + ":" + appStartTimestamp + "]")
    root.geometry("550x610")
    root.resizable(0, 0)
    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.wm_iconbitmap(iconPath)

    canv = Canvas(root)
    canv.pack()
    canv.place(x=479, y=2)
    img = ImageTk.PhotoImage(Image.open(logoPath))
    canv.create_image(0, 0, image=img, anchor="nw")

    countyShpBrowseLabel = Label(root)
    countyShpBrowseLabel.pack()
    countyShpBrowseLabel.place(x=15, y=8)
    countyShpBrowseLabel.config(text="County/State Shape File")

    countyShpBrowsebutton = Button(root, text="Browse",
                                command=lambda: browseFilesFunc(countyShpBrowsebutton, [('Shape Files', '*.shp')]))
    countyShpBrowsebutton.pack()
    countyShpBrowsebutton.place(width=310, height=30)
    countyShpBrowsebutton.place(x=155, y=8)
    countyShpBrowsebutton_ttp = CreateToolTip(countyShpBrowsebutton, "Optional. Browse County/State Shapefile")

    vrgShpBrowseLabel = Label(root)
    vrgShpBrowseLabel.pack()
    vrgShpBrowseLabel.place(x=15, y=45)
    vrgShpBrowseLabel.config(text="VRG Shapes Folder")

    vrgShpBrowsebutton = Button(root, text="Browse", command=lambda: browseDirectoryFunc(vrgShpBrowsebutton))
    vrgShpBrowsebutton.pack()
    vrgShpBrowsebutton.place(width=310, height=30)
    vrgShpBrowsebutton.place(x=155, y=45)
    vrgShpBrowsebutton_ttp = CreateToolTip(vrgShpBrowsebutton, "Browse folder containing only VRG Polygons Shapefiles")

    refshapebrowseLabel = Label(root)
    refshapebrowseLabel.pack()
    refshapebrowseLabel.place(x=15, y=85)
    refshapebrowseLabel.config(text="Reference Shape File")

    refshapebrowsebutton = Button(root, text="Browse", command=lambda: browseFilesFunc(refshapebrowsebutton,[('Shape Files','*.shp')]))
    refshapebrowsebutton.pack()
    refshapebrowsebutton.place(width=370, height=30)
    refshapebrowsebutton.place(x=155, y=85)
    refshapebrowsebutton_ttp = CreateToolTip(refshapebrowsebutton, "Browse Postcode or County or any reference Shapefile. Points and Polygons geometries allowed.")

    outfolderbrowseLabel = Label(root)
    outfolderbrowseLabel.pack()
    outfolderbrowseLabel.place(x=15, y=125)
    outfolderbrowseLabel.config(text="Output Folder")

    outfolderbrowsebutton = Button(root, text="Browse",
                                  command=lambda: browseDirectoryFunc(outfolderbrowsebutton))
    outfolderbrowsebutton.pack()
    outfolderbrowsebutton.place(width=370, height=30)
    outfolderbrowsebutton.place(x=155, y=125)
    outfolderbrowsebutton_ttp = CreateToolTip(outfolderbrowsebutton, "Browse output folder location (must have right access)")


    serverLbl = Label(root)
    serverLbl.pack()
    serverLbl.place(x=15, y=170)
    serverLbl.config(text="SQL Server")

    serverVar = StringVar(root)

    serverEntry = ttk.Combobox(root,textvariable=serverVar)
    serverEntry.place(width=370, height=25)
    serverEntry.place(x=155, y=170)
    serverEntry['values'] = getFavouriteServersTuple()
    serverEntry_ttp = CreateToolTip(serverEntry,"Select SQL Server Instance")

    tkVar = StringVar(root)
    tkVar.set('Windows Authentication')

    connLabel = Label(root)
    connLabel.pack()
    connLabel.place(x=15, y=210)
    connLabel.config(text="Connection Mode")

    authMethodMenu = OptionMenu(root, tkVar, *authChoices,
                                command=lambda x: conn_method_changed(tkVar, usernameEntry, passwordEntry))
    authMethodMenu.place(width=370, height=30)
    authMethodMenu.place(x=155, y=210)
    authMethodMenu.config(anchor='w')
    authMethodMenu_ttp = CreateToolTip(authMethodMenu, "Select SQL Server Instance Mode of Authentication")

    usernameLabel = Label(root)
    usernameLabel.pack()
    usernameLabel.place(x=155, y=250)
    usernameLabel.config(text="Username")

    usernameEntry = Entry(root)
    usernameEntry.place(width=200, height=25)
    usernameEntry.place(x=240, y=250)
    usernameEntry.config(state='disabled')
    usernameEntry_ttp = CreateToolTip(usernameEntry, "Select SQL Server Instance Username (For SQL Server Authentication)")

    passwordLabel = Label(root)
    passwordLabel.pack()
    passwordLabel.place(x=155, y=295)
    passwordLabel.config(text="Password")

    passwordEntry = Entry(root,show="*")
    passwordEntry.place(width=200, height=25)
    passwordEntry.place(x=240, y=295)
    passwordEntry.config(state='disabled')
    passwordEntry_ttp = CreateToolTip(passwordEntry,
                                      "Select SQL Server Instance password (For SQL Server Authentication)")


    connectButton = Button(root, text="Connect",
                           command=lambda: connectToSQLServer(serverVar.get(), usernameEntry.get(),
                                                              passwordEntry.get(), [databaseEntry], tkVar.get(), dbVar,
                                                              None, serverEntry))
    connectButton.pack()
    connectButton.place(width=77, height=30)
    connectButton.place(x=447, y=292)
    connectButton_ttp = CreateToolTip(connectButton, "Click to connect to SQL Server")

    databaseLbl = Label(root)
    databaseLbl.pack()
    databaseLbl.place(x=15, y=335)
    databaseLbl.config(text="Database")

    dbVar = StringVar(root)

    databaseEntry = ttk.Combobox(root, textvariable=dbVar)
    databaseEntry.place(width=370, height=25)
    databaseEntry.place(x=155, y=335)
    # databaseEntry.config(anchor='w')
    databaseEntry_ttp = CreateToolTip(databaseEntry, "Select a database. To create new type desired database name")

    colsToPopulateLbl = Label(root)
    colsToPopulateLbl.pack()
    colsToPopulateLbl.place(x=15, y=375)
    colsToPopulateLbl.config(text="Columns")

    colsToPopulateText = Text(root)
    colsToPopulateText.pack()
    colsToPopulateText.place(width=370, height=25)
    colsToPopulateText.place(x=155, y=375)
    colsToPopulateText_ttp = CreateToolTip(colsToPopulateText, "Select comma separated columns to populate in VRG from reference shape file."
                                                               "\nPolygons:\n   Minimum 2 columns are required .\n   First Must be Unique Code to populate e.g. POST"
                                                               "\n   Second must be Area column. This will be created in the process. No need to pre-exist. e.g. POST_Area."
                                                               "\nPoints:\n   Minimum 1 column is required as Area column is not required for point geometries")

    outShapeNameLbl = Label(root)
    outShapeNameLbl.pack()
    outShapeNameLbl.place(x=15, y=415)
    outShapeNameLbl.config(text="Output Shape Name")

    outShapeNameText = Text(root)
    outShapeNameText.pack()
    outShapeNameText.place(width=370, height=25)
    outShapeNameText.place(x=155, y=415)
    outShapeNameText_ttp = CreateToolTip(outShapeNameText,"Select output Shapefile name with .shp extension e.g. ABC.shp."
                                                          "\nOptional. Default will be <First_VRG_shapefile_name>_Final.shp")

    outTableNameLbl = Label(root)
    outTableNameLbl.pack()
    outTableNameLbl.place(x=15, y=455)
    outTableNameLbl.config(text="Output Table Name")

    outTableNameText = Text(root)
    outTableNameText.pack()
    outTableNameText.place(width=370, height=25)
    outTableNameText.place(x=155, y=455)
    outTableNameText_ttp = CreateToolTip(outTableNameText,
                                         "Select output table name."
                                         "\nOptional. Default will be <First_VRG_shapefile_name>")

    projEpsgLbl = Label(root)
    projEpsgLbl.pack()
    projEpsgLbl.place(x=15, y=495)
    projEpsgLbl.config(text="EPSG Code")

    projEpsgText = Text(root)
    projEpsgText.pack()
    projEpsgText.place(width=80, height=25)
    projEpsgText.place(x=155, y=495)
    projEpsgText_ttp = CreateToolTip(projEpsgText,"Enter EPSG code of a projected coordinate system in which area will be calculated" )

    statusLabel = Label(root)
    statusLabel.pack()
    statusLabel.place(x=15, y=535)
    statusLabel.config(fg="Blue")

    progressbar = ttk.Progressbar(root, orient='horizontal', length=80, mode="determinate")

    executeButton = Button(root, text="Compute",
                           command=lambda: executeDFComputation(countyShpBrowsebutton.cget("text"),vrgShpBrowsebutton.cget("text"),refshapebrowsebutton.cget("text"),outfolderbrowsebutton.cget("text"), dbVar.get(), serverVar.get(), usernameEntry.get(),
                                                   passwordEntry.get(), tkVar.get(),outShapeNameText.get("1.0",'end-1c'),outTableNameText.get("1.0",'end-1c'),colsToPopulateText.get("1.0",'end-1c'),projEpsgText.get("1.0",'end-1c'),progressbar,statusLabel,
                                                    [vrgShpBrowsebutton,refshapebrowsebutton,outfolderbrowsebutton,serverEntry,authMethodMenu,connectButton,databaseEntry,outShapeNameText,
                                                     countyShpBrowsebutton,outTableNameText,colsToPopulateText,executeButton,projEpsgText],
                                                    usernameEntry,passwordEntry))
    executeButton.pack()
    executeButton.place(width=90, height=30)
    executeButton.place(x=435, y=570)
    executeButton_ttp = CreateToolTip(executeButton,"Click to execute DF Computation Process.")

    root.mainloop()

############################################# Main method  ############################################################################
if __name__=='__main__':
    multiprocessing.freeze_support()
    appStartTimestamp = strftime("%Y_%m_%d_%H_%M_%S", localtime())
    logFilePath = os.path.join(logFolderPath, "DF_Computation_" + appVersion + "_" + appStartTimestamp + ".txt")
    createUI(appStartTimestamp)
